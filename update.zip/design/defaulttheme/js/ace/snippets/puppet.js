ace.define("ace/snippets/puppet",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="puppet"});                (function() {
                    ace.require(["ace/snippets/puppet"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            